package com.example.team09app;

//This class holds the goal data, not attached to an activity
public class GoalData {
}
